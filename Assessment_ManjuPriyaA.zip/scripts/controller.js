var myAPp = angular.module("myModule",[])
.controller("myController",function($scope){
	$scope.loadPage = "pages/login.html";
	$scope.btnValue="Add";
	$scope.pageDetails="Enter details to login";
	var data = [
	{sno:"1",firstname:"Manju", middlename: "priya", lastname:"a", email:"am@gmail.com", mobile:"2131233456", password:"Abc@gmail.com", confirmpass:"Abc@gmail.com"},
	{sno:"2",firstname:"densi", middlename: "deva", lastname:"raj", email:"densi@gmail.com", mobile:"9484746444", password:"Bbc@gmail.com", confirmpass:"Bbc@gmail.com"},
	{sno:"3",firstname:"deva", middlename: "dharshini", lastname:"ds", email:"ds@gmail.com", mobile:"9874568745", password:"Dbc@gmail.com", confirmpass:"Dbc@gmail.com"},
	{sno:"4",firstname:"jaanu", middlename: "ram", lastname:"jn", email:"jn@gmail.com", mobile:"2131233456", password:"Jn@gmail.com", confirmpass:"Jn@gmail.com"}
	];
	$scope.userDeatils = data;
	$scope.login = function(username, password){
		if(username=="user@gmail.com" && password =="123456"){
			var name = username.split("@");
			$scope.pageDetails = "Welcome..."+name[0];
			$scope.loadPage = "pages/manageusers.html";
			$scope.userDeatils = data;
		}else{
			$scope.errorMsg = "Username/Password is wrong";
		}
	}
	$scope.gotoRegister = function(){
		$scope.loadPage = "pages/register.html";
	}
	$scope.itemIndex = "";
	$scope.editUser = function(data){
		$scope.clearFields();
		$scope.btnValue = "Update";
		var index = $scope.userDeatils.indexOf(data);
		$scope.itemIndex = index;
		var editItems={
			editFirstname:data.firstname,
			editMiddlename:data.middlename,
			editLastname:data.lastname,
			editEmail:data.email,
			editMobile:data.mobile,
			editPassword:data.password,
			editConfirmPass:data.confirmpass
		};
		$scope.editflag=1;
		$scope.editDetails=editItems;
	}
	$scope.deleteUser = function(data){
		var index = $scope.userDeatils.indexOf(data);
		$scope.userDeatils.splice(index, 1);
	}
	$scope.clearFields = function(data){
		$scope.btnValue = "Add";
		$scope.itemIndex = $scope.userDeatils.length-1;
		var items={
			editFirstname:"",
			editMiddlename:"",
			editLastname:"",
			editEmail:"",
			editMobile:"",
			editPassword:"",
			editConfirmPass:""
		};
		$scope.editDetails=items;
	}
	$scope.saveDetails = function(data){
		if($scope.btnValue=="Update"){
			var items={
				sno:$scope.itemIndex+1,
				firstname:data.editFirstname,
				middlename:data.editMiddlename,
				lastname:data.editLastname,
				email:data.editEmail,
				mobile:data.editMobile,
				password:data.editPassword,
				confirmpass:data.editConfirmPass
			};
			$scope.userDeatils[$scope.itemIndex]=items;
			$scope.clearFields();
		}else if($scope.btnValue=="Add"){
			$scope.itemIndex = $scope.userDeatils.length;
			var items={
				sno:$scope.itemIndex+1,
				firstname:data.editFirstname,
				middlename:data.editMiddlename,
				lastname:data.editLastname,
				email:data.editEmail,
				mobile:data.editMobile,
				password:data.editPassword,
				confirmpass:data.editConfirmPass
			};
			$scope.userDeatils[$scope.itemIndex]=items;
			$scope.clearFields();
		}
		
	}
	$scope.register = function(data){
		if($scope.validateForm(data)){
			console.log(data);
			$scope.itemIndex = $scope.userDeatils.length;
			var items={
				sno:$scope.itemIndex+1,
				firstname:data.firstname,
				middlename:data.middlename,
				lastname:data.lastname,
				email:data.email,
				mobile:data.mobile,
				password:data.password,
				confirmpass:data.confirmpass
			};
			$scope.userDeatils[$scope.itemIndex]=items;
			$scope.loadPage = "pages/login.html";
		}
	}
	$scope.backToLogin = function(){
		$scope.loadPage = "pages/login.html";
	}
	$scope.validateForm = function(data){
		if(!data){
			return false;
		}else{
			/*To validate email mobile number*/
			if(data.mobile){
				if(data.mobile.length < 10){
					$scope.mobileError = "Mobile number must be have 10 digits";
					return false;
				}else{
					$scope.mobileError="";
				}
			}
			/*To validate Password number*/
			if(data.password.length == data.confirmpass.length){
				if(data.password == data.confirmpass){
					$scope.passwordError = "";
					return true;
				}
				else{
					$scope.passwordError = "Password and confirm password must be same";
					return false;
				}
			}else{
				$scope.passwordError = "Password and confirm password must have same length";
				return false;
			}
		}
	}
});
